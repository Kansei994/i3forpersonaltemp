#!/usr/bin/python

import dbus
import os
import sys

try:
    bus = dbus.SessionBus()
    spotify = bus.get_object("org.mpris.MediaPlayer2.spotify", "/org/mpris/MediaPlayer2")

    control_iface = dbus.Interface(spotify, 'org.mpris.MediaPlayer2.Player')
    
    # Inputs
    if os.environ.get('BLOCK_BUTTON'):
        if os.environ['BLOCK_BUTTON'] == '2':
            control_iface.Previous()
        elif os.environ['BLOCK_BUTTON'] == '1':
            control_iface.PlayPause()
        elif os.environ['BLOCK_BUTTON'] == '3':
            control_iface.Next()
        
        # Send signal
        os.system("pkill -RTMIN+3 i3blocks") 
    spotify_iface = dbus.Interface(spotify, 'org.freedesktop.DBus.Properties')
    props = spotify_iface.Get('org.mpris.MediaPlayer2.Player', 'Metadata')
    playback_status = spotify_iface.Get('org.mpris.MediaPlayer2.Player', 'PlaybackStatus')

    artist = str(props['xesam:artist'][0])
    title = str(props['xesam:title'])

    # Display
    if playback_status == 'Paused':
        info = "Paused -"
    else:
        info = "Playing -"

    if sys.version_info > (3, 0):
        print(f"{info} {artist} - {title}")
    else:
        print((info + " - " + artist + " - " + title).encode('utf-8'))

    exit()

except dbus.exceptions.DBusException:
    exit()
